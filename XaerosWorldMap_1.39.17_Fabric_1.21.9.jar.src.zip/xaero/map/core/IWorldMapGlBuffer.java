package xaero.map.core;

public interface IWorldMapGlBuffer {
  int xaero_wm_getHandle();
}


/* Location:              C:\Users\PC\Downloads\xaero-map-viewer\XaerosWorldMap_1.39.17_Fabric_1.21.9.jar!\xaero\map\core\IWorldMapGlBuffer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */