package xaero.map.core;

import net.minecraft.class_11228;
import net.minecraft.class_758;

public interface IGameRenderer {
  class_11228 xaero_wm_getGuiRenderer();
  
  class_758 xaero_wm_getFogRenderer();
}


/* Location:              C:\Users\PC\Downloads\xaero-map-viewer\XaerosWorldMap_1.39.17_Fabric_1.21.9.jar!\xaero\map\core\IGameRenderer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */