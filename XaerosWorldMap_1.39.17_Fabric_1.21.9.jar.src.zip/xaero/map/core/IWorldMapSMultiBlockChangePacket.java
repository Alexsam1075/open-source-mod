package xaero.map.core;

import net.minecraft.class_4076;

public interface IWorldMapSMultiBlockChangePacket {
  class_4076 xaero_wm_getSectionPos();
}


/* Location:              C:\Users\PC\Downloads\xaero-map-viewer\XaerosWorldMap_1.39.17_Fabric_1.21.9.jar!\xaero\map\core\IWorldMapSMultiBlockChangePacket.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */