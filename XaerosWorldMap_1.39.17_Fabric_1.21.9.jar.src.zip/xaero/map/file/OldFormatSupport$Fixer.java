package xaero.map.file;

import net.minecraft.class_2487;

public interface Fixer {
  void fix(class_2487 paramclass_2487);
}


/* Location:              C:\Users\PC\Downloads\xaero-map-viewer\XaerosWorldMap_1.39.17_Fabric_1.21.9.jar!\xaero\map\file\OldFormatSupport$Fixer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */