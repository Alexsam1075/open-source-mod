/*    */ package xaero.map.element;
/*    */ 
/*    */ public class MapElementMenuHitbox
/*    */ {
/*    */   private int x;
/*    */   private int y;
/*    */   private int w;
/*    */   private int h;
/*    */   
/*    */   public MapElementMenuHitbox(int x, int y, int w, int h) {
/* 11 */     this.x = x;
/* 12 */     this.y = y;
/* 13 */     this.w = w;
/* 14 */     this.h = h;
/*    */   }
/*    */   
/*    */   public int getX() {
/* 18 */     return this.x;
/*    */   }
/*    */   
/*    */   public int getY() {
/* 22 */     return this.y;
/*    */   }
/*    */   
/*    */   public int getW() {
/* 26 */     return this.w;
/*    */   }
/*    */   
/*    */   public int getH() {
/* 30 */     return this.h;
/*    */   }
/*    */   
/*    */   public void setY(int y) {
/* 34 */     this.y = y;
/*    */   }
/*    */   
/*    */   public void setH(int h) {
/* 38 */     this.h = h;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\xaero-map-viewer\XaerosWorldMap_1.39.17_Fabric_1.21.9.jar!\xaero\map\element\MapElementMenuHitbox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */