/*    */ package xaero.map.graphics.shader;
/*    */ 
/*    */ import net.minecraft.class_2960;
/*    */ 
/*    */ public class MapShaders
/*    */ {
/*  7 */   public static class_2960 WORLD_MAP = class_2960.method_60655("xaeroworldmap", "core/map");
/*  8 */   public static class_2960 WORLD_MAP_BRANCH = class_2960.method_60655("xaeroworldmap", "core/map_branch");
/*  9 */   public static class_2960 POSITION_COLOR_TEX = class_2960.method_60655("xaeroworldmap", "core/position_color_tex");
/* 10 */   public static class_2960 POSITION_COLOR = class_2960.method_60655("xaeroworldmap", "core/position_color");
/*    */ }


/* Location:              C:\Users\PC\Downloads\xaero-map-viewer\XaerosWorldMap_1.39.17_Fabric_1.21.9.jar!\xaero\map\graphics\shader\MapShaders.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */