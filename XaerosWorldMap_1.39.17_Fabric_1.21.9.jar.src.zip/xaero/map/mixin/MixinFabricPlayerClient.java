package xaero.map.mixin;

import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;

@Mixin({class_1657.class})
public class MixinFabricPlayerClient {}


/* Location:              C:\Users\PC\Downloads\xaero-map-viewer\XaerosWorldMap_1.39.17_Fabric_1.21.9.jar!\xaero\map\mixin\MixinFabricPlayerClient.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */