/*    */ package xaero.map.exception;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SilentException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public SilentException(String string) {
/* 11 */     super(string);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\xaero-map-viewer\XaerosWorldMap_1.39.17_Fabric_1.21.9.jar!\xaero\map\exception\SilentException.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */