package xaero.map.radar.tracker;

import net.minecraft.class_1937;
import net.minecraft.class_4588;
import net.minecraft.class_5321;
import xaero.map.graphics.renderer.multitexture.MultiTextureRenderTypeRenderer;

public class PlayerTrackerMapElementRenderContext {
  public class_4588 textBGConsumer;
  
  public MultiTextureRenderTypeRenderer uniqueTextureUIObjectRenderer;
  
  public class_5321<class_1937> mapDimId;
  
  public double mapDimDiv;
}


/* Location:              C:\Users\PC\Downloads\xaero-map-viewer\XaerosWorldMap_1.39.17_Fabric_1.21.9.jar!\xaero\map\radar\tracker\PlayerTrackerMapElementRenderContext.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */