package xaero.map.controls;

import net.minecraft.class_304;
import net.minecraft.class_3675;

public interface IKeyBindingHelper {
  class_3675.class_306 getBoundKeyOf(class_304 paramclass_304);
  
  boolean modifiersAreActive(class_304 paramclass_304, int paramInt);
}


/* Location:              C:\Users\PC\Downloads\xaero-map-viewer\XaerosWorldMap_1.39.17_Fabric_1.21.9.jar!\xaero\map\controls\IKeyBindingHelper.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */