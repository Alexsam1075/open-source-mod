package xaero.map.controls;

public class KeyConflictContext {
  public static final int GUI = 0;
  
  public static final int IN_GAME = 1;
  
  public static final int UNIVERSAL = 2;
}


/* Location:              C:\Users\PC\Downloads\xaero-map-viewer\XaerosWorldMap_1.39.17_Fabric_1.21.9.jar!\xaero\map\controls\KeyConflictContext.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */