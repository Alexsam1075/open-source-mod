/*   */ package xaero.map.effects;
/*   */ 
/*   */ import net.minecraft.class_4081;
/*   */ 
/*   */ public class NoWorldMapEffect
/*   */   extends WorldMapStatusEffect {
/*   */   protected NoWorldMapEffect(class_4081 type) {
/* 8 */     super(type, -16777216, "no_world_map");
/*   */   }
/*   */ }


/* Location:              C:\Users\PC\Downloads\xaero-map-viewer\XaerosWorldMap_1.39.17_Fabric_1.21.9.jar!\xaero\map\effects\NoWorldMapEffect.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */