/*   */ package xaero.map.effects;
/*   */ 
/*   */ import net.minecraft.class_4081;
/*   */ 
/*   */ public class NoCaveMapsEffect
/*   */   extends WorldMapStatusEffect {
/*   */   protected NoCaveMapsEffect(class_4081 type) {
/* 8 */     super(type, -16777216, "no_cave_maps");
/*   */   }
/*   */ }


/* Location:              C:\Users\PC\Downloads\xaero-map-viewer\XaerosWorldMap_1.39.17_Fabric_1.21.9.jar!\xaero\map\effects\NoCaveMapsEffect.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */