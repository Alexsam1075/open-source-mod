/*   */ package xaero.map.gui;
/*   */ 
/*   */ public class MapMouseButtonPress
/*   */ {
/*   */   public boolean isDown;
/*   */   public boolean clicked;
/* 7 */   public int pressedAtX = -1;
/* 8 */   public int pressedAtY = -1;
/*   */ }


/* Location:              C:\Users\PC\Downloads\xaero-map-viewer\XaerosWorldMap_1.39.17_Fabric_1.21.9.jar!\xaero\map\gui\MapMouseButtonPress.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */