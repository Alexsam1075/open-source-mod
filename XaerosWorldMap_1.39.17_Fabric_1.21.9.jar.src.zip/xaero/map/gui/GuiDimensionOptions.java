/*    */ package xaero.map.gui;
/*    */ 
/*    */ import net.minecraft.class_1937;
/*    */ import net.minecraft.class_5321;
/*    */ 
/*    */ 
/*    */ public class GuiDimensionOptions
/*    */ {
/*    */   public int selected;
/*    */   public final class_5321<class_1937>[] values;
/*    */   
/*    */   public GuiDimensionOptions(int selected, class_5321<class_1937>[] values) {
/* 13 */     this.selected = selected;
/* 14 */     this.values = values;
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\xaero-map-viewer\XaerosWorldMap_1.39.17_Fabric_1.21.9.jar!\xaero\map\gui\GuiDimensionOptions.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */