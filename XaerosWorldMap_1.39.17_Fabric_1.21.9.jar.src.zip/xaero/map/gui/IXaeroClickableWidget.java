package xaero.map.gui;

import java.util.function.Supplier;

public interface IXaeroClickableWidget extends ICanTooltip {
  void setXaero_wm_tooltip(Supplier<CursorBox> paramSupplier);
}


/* Location:              C:\Users\PC\Downloads\xaero-map-viewer\XaerosWorldMap_1.39.17_Fabric_1.21.9.jar!\xaero\map\gui\IXaeroClickableWidget.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */