package xaero.map.gui.dropdown;

public interface IDropDownWidgetCallback {
  boolean onSelected(DropDownWidget paramDropDownWidget, int paramInt);
}


/* Location:              C:\Users\PC\Downloads\xaero-map-viewer\XaerosWorldMap_1.39.17_Fabric_1.21.9.jar!\xaero\map\gui\dropdown\IDropDownWidgetCallback.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */