/*    */ package xaero.map.gui;
/*    */ 
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_4185;
/*    */ 
/*    */ 
/*    */ public class MySmallButton
/*    */   extends class_4185
/*    */ {
/*    */   public MySmallButton(int par1, int par2, class_2561 par3Str, class_4185.class_4241 onPress) {
/* 11 */     super(par1, par2, 150, 20, par3Str, onPress, field_40754);
/*    */   }
/*    */ }


/* Location:              C:\Users\PC\Downloads\xaero-map-viewer\XaerosWorldMap_1.39.17_Fabric_1.21.9.jar!\xaero\map\gui\MySmallButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */